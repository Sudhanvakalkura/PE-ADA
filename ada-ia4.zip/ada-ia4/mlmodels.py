import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LassoCV
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder

# Feature Importance Rankings

# Load dataset
path = r'C:\Users\yashh\Downloads\ev_battery_charging_data.csv'
df = pd.read_csv(path)

## Encode categorical variables
df_encoded = df.copy()
for col in df_encoded.select_dtypes(include='object').columns:
    le = LabelEncoder()
    df_encoded[col] = le.fit_transform(df_encoded[col])

## Define X (features) and y (target)
X = df_encoded.drop(columns=['Optimal Charging Duration Class'])  # Replace with your actual target column
y = df_encoded['Optimal Charging Duration Class']

## Recursive Feature Elimination (RFE)
model = LogisticRegression(max_iter=1000)
rfe = RFE(estimator=model, n_features_to_select=5)
rfe.fit(X, y)

rfe_ranking = pd.Series(rfe.ranking_, index=X.columns).sort_values()

plt.figure(figsize=(10, 5))
rfe_ranking[rfe_ranking <= 10].plot(kind='barh', color='skyblue')
plt.title("Top Features (RFE Ranking: 1 = Most Important)")
plt.xlabel("Ranking")
plt.gca().invert_yaxis()
plt.tight_layout()
plt.show()

## Random Forest Feature Importance
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X, y)

rf_importance = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=True)

plt.figure(figsize=(10, 5))
rf_importance.tail(10).plot(kind='barh', color='forestgreen')
plt.title("Top 10 Features (Random Forest Importance)")
plt.xlabel("Importance Score")
plt.tight_layout()
plt.show()

## Lasso (L1-Regularized Regression)
lasso = LassoCV(cv=5, random_state=42)
lasso.fit(X, y)

lasso_coef = pd.Series(lasso.coef_, index=X.columns)
lasso_coef_nonzero = lasso_coef[lasso_coef != 0].sort_values()

plt.figure(figsize=(10, 5))
lasso_coef_nonzero.plot(kind='barh', color='salmon')
plt.title("Lasso Feature Coefficients (Non-zero)")
plt.xlabel("Coefficient")
plt.tight_layout()
plt.show()

## Summary Table
summary = pd.DataFrame({
    "RFE_Rank": rfe_ranking,
    "RF_Importance": rf_importance,
    "Lasso_Coefficient": lasso_coef
}).sort_values(by="RFE_Rank")

print("\nTop Features Summary:")
print(summary.head(10))