import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from scipy.stats import skew, shapiro, chi2_contingency

# Load dataset into data frame
path = r'C:\Users\yashh\Downloads\ev_battery_charging_data.csv'
df = pd.read_csv(path)

# Conversion from multinomial to numeric
le = LabelEncoder()
df['Charging Mode'] = le.fit_transform(df['Charging Mode'])
df['Battery Type'] = le.fit_transform(df['Battery Type'])
df['EV Model'] = le.fit_transform(df['EV Model'])

# Creating the correlation matrix
corr_matrix = df.corr()

## Create the plot
fig, ax = plt.subplots(figsize=(10, 8))
cax = ax.matshow(corr_matrix, cmap='coolwarm')

## Add color bar
plt.colorbar(cax)

## Set ticks and labels
ax.set_xticks(range(len(corr_matrix.columns)))
ax.set_yticks(range(len(corr_matrix.columns)))

ax.set_xticklabels(corr_matrix.columns, rotation=90)
ax.set_yticklabels(corr_matrix.columns)

plt.title("Correlation Matrix", pad=20)
plt.tight_layout()
plt.show()

# Distribution Analysis

## Summary Stats
print(df.describe())

## Load your dataset
df = pd.read_csv(path)

## Numerical features
numerical_cols = [
    'SOC (%)', 'Voltage (V)', 'Current (A)', 'Battery Temp (°C)',
    'Ambient Temp (°C)', 'Charging Duration (min)', 'Degradation Rate (%)',
    'Efficiency (%)', 'Charging Cycles'
]

for col in numerical_cols:
    print(f"\n--- {col} ---")
    s = skew(df[col])
    k = df[col].kurtosis()

    print(f"\nFeature: {col}")
    print(f"Skewness: {s:.2f}")
    if s > 0:
        print("Right-skewed Distribution")
    elif s < 0:
        print("Left-skewed Distribution")
    else:
        print("Symmetric Distribution")

    print(f"Kurtosis: {k:.2f}")
    if k > 0:
        print("Extreme outliers are frequent (Leptokurtic)")
    elif k < 0:
        print("Extreme outliers are rare (Platykurtic)")
    else:
        print("Normal distribution-like (Mesokurtic)")

    ## Shapiro-Wilk test for normality
    stat, p = shapiro(df[col])
    print(f"Shapiro-Wilk Test p-value: {p:.4f}")
    if p > 0.05:
        print("Likely Gaussian/Normal distribution")
    else:
        print("Not normally distributed")

    ## Boxplot for outlier detection
    plt.figure(figsize=(10, 4))
    plt.subplot(1, 2, 1)
    sns.histplot(df[col], kde=True, bins=30)
    plt.title(f'Distribution of {col}')

    plt.subplot(1, 2, 2)
    sns.boxplot(x=df[col])
    plt.title(f'Boxplot of {col}')
    plt.tight_layout()
    plt.show()

# Ch-Square Test

## Pairs to test: each with Optimal Charging Duration Class (target class)
cat_cols = ['Charging Mode', 'Battery Type', 'EV Model']
target_col = 'Optimal Charging Duration Class'

for col in cat_cols:
    print(f"\nChi-Square Test between '{col}' and '{target_col}'")

    contingency_table = pd.crosstab(df[col], df[target_col])
    print("Contingency Table:")
    print(contingency_table)

    chi2, p, dof, expected = chi2_contingency(contingency_table)
    print(f"Chi2 Statistic: {chi2:.4f}")
    print(f"p-value: {p:.4f}")

    if p < 0.05:
        print("Significant association")
    else:
        print("No significant association")